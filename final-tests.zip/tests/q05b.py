test = {
  'name': '5b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> total_high_cost_ma
          22505
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
