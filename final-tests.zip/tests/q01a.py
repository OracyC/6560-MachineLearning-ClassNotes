test = {
  'name': '1a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> "{0:.4f}".format(round( cost_ma,4))
          '17.9063'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
